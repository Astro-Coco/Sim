### OPTIMISATION SCRIPT ###
#Technique : brute force

import subprocess
import json
import os
import numpy as np

# List of JSON file paths
json_files = ['config-30k-29-octobre-2023']
deviation = 10 #in percent
for json_file in json_files:
    
    # Modify the JSON file if needed
    for scaling in np.linspace((1-deviation/100),1+deviation/100, 11):
        print(scaling)
        with open(json_file+'.json', 'r') as file:
            data = json.load(file)
            data['nozzle']['at'] *= scaling

        modified_json_file = f"{json_file}_scale_{int(scaling*100)}.json"
        # Save the modified JSON file
        with open(modified_json_file, 'w') as file:
            json.dump(data, file)
            print(data)

        # Run the simulation
        result = subprocess.run(['python', 'mot_colin.py', '-f', modified_json_file],
                        capture_output=True, text=True)

        # Print the output and error (if any)
        print(result.stdout)
        if result.stderr:
            print("Error:", result.stderr)
        # Optional: collect results and store them
    # ...
